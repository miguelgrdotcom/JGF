package hu.test.nulloutput;

public interface NullOutputRunner
{
    public void run();
}
