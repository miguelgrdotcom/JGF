package hu.list;

public interface HUMapper <T, U> {
	public U apply(T o);
}
